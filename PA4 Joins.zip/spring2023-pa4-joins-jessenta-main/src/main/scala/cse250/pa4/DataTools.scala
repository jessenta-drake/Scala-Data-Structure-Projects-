/**
 * cse250.pa4.DataTools.scala
 *
 * Copyright 2022 Oliver Kennedy (okennedy@buffalo.edu)
 *           2022 Eric Mikida (epmikida@buffalo.edu)
 *
 * This work is licensed under the Creative Commons
 * Attribution-NonCommercial-ShareAlike 4.0 International License.
 * To view a copy of this license, visit
 * http://creativecommons.org/licenses/by-nc-sa/4.0/.
 *
 */
 package cse250.pa4

import java.io.File
import java.text.DateFormat
import java.util.Date

import scala.io.Source
import scala.collection.mutable
import java.util.GregorianCalendar

object DataTools {
  /**
   * Convert date string (e.g., MM/DD/YYYY) to a [[Date]]
   *
   * @param dateString A date string in a standard format like MM/DD/YYYY
   * @return A [[Date]] encoding dateString
   */
  def parseDate(dateString: String): Date = {
    if (dateString == "") {
      return null
    }
    DateFormat.getDateInstance(DateFormat.SHORT).parse(dateString)

  }

  /**
   * Load a sequence of "anonymized" [[HealthRecord]]s from a CSV file
   *
   * @param filename The path to a CSV file.
   * @return The [[HealthRecord]] objects loaded from the file.
   *
   *         This function should make the following assumptions about the CSV file:
   *         1. The first line of the CSV file is a header.
   *         2. Header fields are
   *         * "Birthday"
   *         * "Zip Code"
   *         * "Blood Type"
   *         * "Allergic to Dogs?"
   *         * "Allergic to Cats?"
   *         * "Allergic to Peanuts?"
   *         * "Allergic to Gluten?"
   *         3. Every subsequent line may be split into fields with [[String]]'s split method
   *         4. Columns containing dates are in a format interpretable by [[parseDate]]
   *         5. Columns containing strings may not have consistent capitalization
   *         6. Valid blood types are A+, A-, B+, B-, O+, O-, AB+, AB-. If the bloodtype in the
   *         csv file does not match one of these (modulo capitalization) it should be entered
   *         as N/A
   *         7. Columns related to allergies will contain strings "yes" or "no"
   *
   *         Examples of valid CSV files can be found in `src/test/resources/`
   */
  def loadHealthRecords(filename: File): Seq[HealthRecord] = {
    var theseq: Seq[HealthRecord] = Seq()
    val inputFile = Source.fromFile(filename)
    val lines = inputFile.getLines().drop(1)
    for (line <- lines) {
      var split = line.split(",")

      var checkbday = split(0)
      var checkzipcode = split(1)
      var checkbloodtype = split(2).toUpperCase
      var checkwoof = true
      var checkmeow = true
      var checkpeanut = true
      var checkgluten = true

      //      if(split.length==7) {
      //        if (split(1) == "") {
      //          split(1) = null
      //        }
      //        else{
      //          checkzipcode=split(1)
      //        }
      //      }
      //      if(split.length==7) {
      //        if (split(2) == "") {
      //          split(2) = "N/A"
      //        }
      //        else{
      //          checkbloodtype=split(1)
      //        }
      //      }
      //      if(split.length==6){
      //        checkzipcode=null
      //      }
      //      if(split.length==6){
      //        checkbloodtype="N/A"
      //      }

      if (split(0) == "") {
        checkbday = null
      }
      if (split(1) == "") {
        checkzipcode = null
      }
      if (!(split(2).toUpperCase == "A+" || split(2).toUpperCase == "A-" || split(2).toUpperCase == "B+" || split(2).toUpperCase == "B-" || split(2).toUpperCase == "O-" || split(2).toUpperCase == "O+" || split(2).toUpperCase == "AB-" || split(2).toUpperCase == "AB+")) {
        checkbloodtype = "N/A"
      }
      if (split(3).equalsIgnoreCase("Yes")) {
        checkwoof = true
      }
      if (split(4).equalsIgnoreCase("Yes")) {
        checkmeow = true
      }
      if (split(5).equalsIgnoreCase("Yes")) {
        checkpeanut = true
      }
      if (split(6).equalsIgnoreCase("Yes")) {
        checkgluten = true
      }
      if (split(3).equalsIgnoreCase("No")) {
        checkwoof = false
      }
      if (split(4).equalsIgnoreCase("No")) {
        checkmeow = false
      }
      if (split(5).equalsIgnoreCase("No")) {
        checkpeanut = false
      }
      if (split(6).equalsIgnoreCase("No")) {
        checkgluten = false
      }
      var thehealthrecord = new HealthRecord(DataTools.parseDate(checkbday), checkzipcode, checkbloodtype, checkwoof, checkmeow, checkpeanut, checkgluten)
      theseq :+= thehealthrecord
    }
    theseq
  }

  /**
   * Load a sequence of [[VoterRecord]]s from a CSV file
   *
   * @param filename The path to a CSV file.
   * @return The [[VoterRecord]] objects loaded from the file.
   *
   *         This function should make the following assumptions:
   *         1. The first line of the CSV file is a header.
   *         2. Header fields are
   *         * "First Name"
   *         * "Last Name"
   *         * "Birthday"
   *         * "Zip Code"
   *         3. Every subsequent line may be split into fields with [[String]]'s split method
   *         4. Columns containing dates are in a format interpretable by [[parseDate]]
   *
   *         Examples of valid CSV files can be found in `src/test/resources/`
   */

  def checkvoterreq(astring: String): String = {
    if (astring == "") {
      null
    }
    else {
      astring
    }
  }

  def loadVoterRecords(filename: File): Seq[VoterRecord] = {
    var theseq: Seq[VoterRecord] = Seq()
    val inputFile = Source.fromFile(filename)
    val lines = inputFile.getLines().drop(1)
    for (line <- lines) {
      var split = line.split(",")
      if (split.length == 4) {
        var thehealthrecord = new VoterRecord(split(0), split(1), DataTools.parseDate(split(2)), checkvoterreq(split(3)))
        theseq :+= thehealthrecord
      }
      else if (split.length == 3) {
        var thehealthrecord = new VoterRecord(split(0), split(1), DataTools.parseDate(split(2)), null)
        theseq :+= thehealthrecord
      }
      //      var checkzipcode = ""
      //      var checkbday = ""
      //      var thelength = split.length
      //      if (line.nonEmpty) {
      //        if (thelength == 4) {
      //          if (split(3) == "") {
      //            split(3) = null
      //          }
      //          else {
      //            checkzipcode = split(3)
      //          }
      //
      //          if (thelength == 3) {
      //            checkzipcode = null
      //          }
      //          if (split(2) == "") {
      //            checkbday = null
      //          }
      //          if (split(2) != "") {
      //            checkbday = split(2)
      //          }
      //
      //          if (thelength > 4 && split(3) == "") {
      //            //if (split(3) == "") {
      //            checkzipcode = null
      //            //}
      //          }
      //        }
      //      }

      //theseq :+= thehealthrecord
    }
    theseq
  }

  /**
   * De-anonymize a collection of "anonymized" [[HealthRecord]] objects using [[VoterRecord]]s
   *
   * @param voterRecords  A [[Seq]]uence of [[VoterRecord]]s containing names.
   * @param healthRecords A [[Seq]]uence of "anonymized" [[HealthRecord]]s.
   * @return A [[Map]] of Full Names associated with their [[HealthRecord]]s.
   *
   *         For every [[HealthRecord]] that can be **uniquely** linked to a
   *         [[VoterRecord]], this function should return a key-value pair.
   *         The key should be the return value of the [[VoterRecord]]'s `fullName`
   *         method.  The value should be the (**unique**) associated
   *         [[HealthRecord]].
   *
   *         If a [[VoterRecord]] can not be associated to any [[HealthRecord]],
   *         or if it can not be **uniquely** associated to just one
   *         [[HealthRecord]], it should not be present in the result set.
   *
   *         This function **must** run in O(voterRecords.size + healthRecords.size)
   */
  //  def identifyPersons(voterRecords: Seq[VoterRecord], healthRecords: Seq[HealthRecord]): mutable.Map[String, HealthRecord] = {
  //    //create hashmap
  //    var myMap: mutable.HashMap[(Date, String), List[HealthRecord]] = mutable.HashMap()
  //    var bdaymap: mutable.HashMap[Date, List[HealthRecord]] = mutable.HashMap()
  //    var zipmap: mutable.HashMap[String, List[HealthRecord]] = mutable.HashMap()
  //    var allbdays: mutable.HashMap[(Date), List[HealthRecord]] = mutable.HashMap()
  //    var allzips: mutable.HashMap[(String), List[HealthRecord]] = mutable.HashMap()
  //
  //
  //    var thetracker: mutable.HashMap[(Date, String), VoterRecord] = mutable.HashMap()
  //    var thetrackers: mutable.HashMap[(Date), VoterRecord] = mutable.HashMap()
  //    var thetrackerss: mutable.HashMap[(String), VoterRecord ]= mutable.HashMap()
  //    var outputMap: mutable.Map[String, HealthRecord] = mutable.Map()
  //    var outputtMap: mutable.Map[String, HealthRecord] = mutable.Map()
  //    var outtielist: List[String] = List()
  //    var outtieslist: List[String] = List()
  //
  //
  //
  //    //load in the health records
  //    for (i <- healthRecords) {
  ////      if (allbdays.contains(i.m_Birthday)) {
  ////        allbdays.update(i.m_Birthday, i :: allbdays(i.m_Birthday))
  ////      }
  ////      if (allzips.contains(i.m_ZipCode)) {
  ////        allzips.update(i.m_ZipCode, i :: allzips(i.m_ZipCode))
  ////      }
  ////      if (!allbdays.contains(i.m_Birthday)) {
  ////        allbdays += (i.m_Birthday -> List(i))
  ////      }
  ////      if (!allzips.contains(i.m_ZipCode)) {
  ////        allzips += (i.m_ZipCode -> List(i))
  ////      }
  //      if (i.m_ZipCode != null && i.m_Birthday != null) {
  //        if (myMap.contains(i.m_Birthday, i.m_ZipCode)) {
  //          myMap.update((i.m_Birthday, i.m_ZipCode), i :: myMap(i.m_Birthday, i.m_ZipCode))
  //          //          allbdays.update(i.m_Birthday,i :: myMap(i.m_Birthday, i.m_ZipCode))
  //          //          allzips.update(i.m_ZipCode,i :: myMap(i.m_Birthday, i.m_ZipCode))
  //        }
  //
  //        else {
  //          var aList: List[HealthRecord] = List(i)
  //          myMap += (i.m_Birthday, i.m_ZipCode) -> aList
  //        }
  //
  //        if (bdaymap.contains(i.m_Birthday)) {
  //          bdaymap.update((i.m_Birthday), i :: bdaymap(i.m_Birthday))
  //
  //        }
  //        else {
  //          var aList: List[HealthRecord] = List(i)
  //          bdaymap += (i.m_Birthday -> aList)
  //        }
  //
  //        if (zipmap.contains(i.m_ZipCode)) {
  //          zipmap.update((i.m_ZipCode), i :: zipmap(i.m_ZipCode))
  //        }
  //        else {
  //          var aList: List[HealthRecord] = List(i)
  //          zipmap += (i.m_ZipCode) -> aList
  //        }
  //
  //      }
  //      else if (i.m_ZipCode == null && i.m_Birthday != null) {
  //        if (bdaymap.contains(i.m_Birthday)) {
  //          bdaymap.update((i.m_Birthday), i :: bdaymap(i.m_Birthday))
  //
  //        }
  //        else {
  //          var aList: List[HealthRecord] = List(i)
  //          bdaymap += (i.m_Birthday -> aList)
  //        }
  //      }
  //      else if (i.m_ZipCode != null && i.m_Birthday == null) {
  //        if (zipmap.contains(i.m_ZipCode)) {
  //          zipmap.update((i.m_ZipCode), i :: zipmap(i.m_ZipCode))
  //        }
  //        else {
  //          var aList: List[HealthRecord] = List(i)
  //          zipmap += (i.m_ZipCode) -> aList
  //        }
  //      }
  //    }
  //    println(myMap)
  //    println(bdaymap)
  //    println(zipmap)
  //    println(allbdays)
  //    println(allzips)
  //    for (j <- voterRecords) {
  //      if (j.m_Birthday != null && j.m_ZipCode == null) {
  //        thetrackers.update(j.m_Birthday, j)
  //      }
  //      if (j.m_Birthday == null && j.m_ZipCode != null) {
  //        thetrackerss.update(j.m_ZipCode, j)
  //      }
  //      if (j.m_Birthday != null && j.m_ZipCode != null) {
  //        if (thetrackers.contains(j.m_Birthday)) {
  //          thetracker.update((j.m_Birthday, j.m_ZipCode), j)
  //        }
  //        if (thetrackerss.contains(j.m_ZipCode)) {
  //          thetracker.update((j.m_Birthday, j.m_ZipCode), j)
  //        }
  //      }
  ////      if (j.m_Birthday != null) {
  ////        thetrackers.update(j.m_Birthday, j :: thetrackers.getOrElse(j.m_Birthday,List()))
  ////      }
  ////      if (j.m_ZipCode != null) {
  ////        thetrackerss.update(j.m_ZipCode, j::thetrackerss.getOrElse(j.m_ZipCode,List()))
  ////      }
  ////      if (j.m_Birthday != null && j.m_ZipCode != null) {
  ////
  ////          thetracker.update((j.m_Birthday, j.m_ZipCode), j:: thetracker.getOrElse((j.m_Birthday,j.m_ZipCode),List()))
  ////      }
  //    }
  //    //          if (j.m_Birthday != null && j.m_ZipCode == null) {
  //    //            if (bdaymap.contains(j.m_Birthday)) {
  //    //              if (bdaymap(j.m_Birthday).length == 1 && !outputMap.contains(j.fullName)) {
  //    //                outputMap(j.fullName) = bdaymap(j.m_Birthday).head
  //    //              }
  //    //            }
  //    //          }
  //    //          if (j.m_Birthday == null && j.m_ZipCode != null) {
  //    //            if (zipmap.contains(j.m_ZipCode)) {
  //    //              if (zipmap(j.m_ZipCode).length == 1 && !outputMap.contains(j.fullName)) {
  //    //                outputMap(j.fullName) = zipmap(j.m_ZipCode).head
  //    //              }
  //    //            }
  //    //          }
  //    //    for (j <- voterRecords) {
  //    //      if (myMap.contains(j.m_Birthday, j.m_ZipCode)) {
  //    //        if (myMap(j.m_Birthday, j.m_ZipCode).length == 1) {
  //    //          if (!outputMap.contains(j.fullName) && !thetracker.contains(j.m_Birthday, j.m_ZipCode) && (!thetrackers.contains(j.m_Birthday)) && !thetrackerss.contains(j.m_ZipCode)) {
  //    //            thetracker.update((j.m_Birthday, j.m_ZipCode), j)
  //    //            outputMap.update(j.fullName, (myMap(j.m_Birthday, j.m_ZipCode).head))
  //    //          }
  //    //          else {
  //    //            outputMap -= j.fullName
  //    //            outputtMap.update(j.fullName, (myMap(j.m_Birthday, j.m_ZipCode).head))
  //    //          }
  //    //        }
  //    //      }
  //    //            if (bdaymap.contains(j.m_Birthday)) {
  //    //              if (bdaymap(j.m_Birthday).length == 1) {
  //    //                if (!outputMap.contains(j.fullName) && !thetracker.contains(j.m_Birthday, j.m_ZipCode) && (!thetrackers.contains(j.m_Birthday))) {
  //    //                  thetrackers.update((j.m_Birthday), j)
  //    //                  outputMap.update(j.fullName, (bdaymap(j.m_Birthday).head))
  //    //                }
  //    //                else {
  //    //                  outputMap -= j.fullName
  //    //                  outputtMap.update(j.fullName,(bdaymap(j.m_Birthday).head))
  //    //                }
  //    //              }
  //    //            }
  //    //            if (zipmap.contains(j.m_ZipCode)) {
  //    //              if (zipmap(j.m_ZipCode).length == 1) {
  //    //                if (!outputMap.contains(j.fullName) && !thetracker.contains(j.m_Birthday, j.m_ZipCode) &&  !thetrackerss.contains(j.m_ZipCode)) {
  //    //                  thetrackerss.update((j.m_ZipCode), j)
  //    //                  outputMap.update(j.fullName, (zipmap(j.m_ZipCode).head))
  //    //                }
  //    //                else {
  //    //                  outputMap -= j.fullName
  //    //                  outputtMap.update(j.fullName,(zipmap(j.m_ZipCode).head))
  //    //                }
  //    //              }
  //    //            }
  //    //            if (allbdays.contains(j.m_Birthday)) {
  //    //              if (allbdays(j.m_Birthday).length == 1) {
  //    //                if (!outputMap.contains(j.fullName) && !thetracker.contains(j.m_Birthday, j.m_ZipCode) && (!thetrackers.contains(j.m_Birthday))) {
  //    //                  thetrackers.update((j.m_Birthday), j)
  //    //                  outputMap.update(j.fullName, (allbdays(j.m_Birthday).head))
  //    //                }
  //    //                else {
  //    //                  outputMap -= j.fullName
  //    //                  outputtMap.update(j.fullName,(allbdays(j.m_Birthday).head))
  //    //                }
  //    //              }
  //    //            }
  //    //            if (allzips.contains(j.m_ZipCode)) {
  //    //              if (allzips(j.m_ZipCode).length == 1) {
  //    //                if (!outputMap.contains(j.fullName) && !thetracker.contains(j.m_Birthday, j.m_ZipCode)  && !thetrackerss.contains(j.m_ZipCode)) {
  //    //                  thetrackerss.update((j.m_ZipCode), j)
  //    //                  outputMap.update(j.fullName, (allzips(j.m_ZipCode).head))
  //    //                }
  //    //                else {
  //    //                  outputMap -= j.fullName
  //    //                  outputtMap.update(j.fullName,(allzips(j.m_ZipCode).head))
  //    //                }
  //    //              }
  //    //            }
  //    //          }for
  //
  //
  //    println("start")
  //
  //    println(thetracker)
  //    println(thetrackers)
  //    println(thetrackerss)
  //
  //    println("end")
  //      for(j <- voterRecords) {
  //        if(j.m_Birthday !=null && j.m_ZipCode !=null) {
  //          if (myMap.contains(j.m_Birthday, j.m_ZipCode)) {
  //            if (myMap(j.m_Birthday, j.m_ZipCode).length == 1) {
  //              if (!outputMap.contains(j.fullName) && !thetracker.contains(j.m_Birthday, j.m_ZipCode) && (!thetrackers.contains(j.m_Birthday)) && !thetrackerss.contains(j.m_ZipCode)) {
  //                thetracker.update((j.m_Birthday, j.m_ZipCode), j)
  //                outputMap.update(j.fullName, (myMap(j.m_Birthday, j.m_ZipCode).head))
  //              }
  //              else {
  //                outputMap -= j.fullName
  //                //outputtMap.update(j.fullName,(myMap(j.m_Birthday, j.m_ZipCode).head))
  //              }
  //            }
  //          }
  //          //          if (myMap.contains(j.m_Birthday, j.m_ZipCode)) {
  //          //            if (myMap(j.m_Birthday, j.m_ZipCode).length == 1) {
  //          //              if (thetracker(j.m_Birthday, j.m_ZipCode).length == 1 && thetrackers(j.m_Birthday).length==1 & thetrackerss(j.m_ZipCode).length==1) {
  //          //                var abool:Boolean = true
  //          //                for(i <- thetrackers(j.m_Birthday)){
  //          //                  if( i.m_ZipCode == j.m_ZipCode && i.fullName != j.fullName){
  //          //                    abool=false
  //          //                  }
  //          //
  //          //                }
  //          //                for(i <- thetrackerss(j.m_ZipCode)){
  //          //                  if(i.m_Birthday == j.m_Birthday && i.fullName != j.fullName){
  //          //                    abool=false
  //          //                  }
  //          //                }
  //          //
  //          //                if(abool) {
  //          //                  outputMap.update(j.fullName, (myMap(j.m_Birthday, j.m_ZipCode).head))
  //          //                }
  //          //            }
  //          //          }
  //          ////            else {
  //          ////              outputMap -= j.fullName
  //          ////            }
  //          //          }
  //          //          else{
  //          //            if (bdaymap.contains(j.m_Birthday)) {
  //          //              if(!(zipmap.contains(j.m_ZipCode )&& zipmap(j.m_ZipCode).length==1)){
  //          //                if (bdaymap(j.m_Birthday).length == 1) {
  //          //                  if (thetrackers(j.m_Birthday).length == 1) {
  //          //                    var abool:Boolean = true
  //          //                    for(i <- thetrackers(j.m_Birthday)){
  //          //                      if( i.m_ZipCode == j.m_ZipCode && i.fullName != j.fullName){
  //          //                        abool=false
  //          //                      }
  //          //
  //          //                    }
  //          //
  //          //
  //          //                    if(abool) {
  //          //                      outputMap.update(j.fullName, (bdaymap(j.m_Birthday).head))
  //          //                    }
  //          //                }
  //          //              }
  //          //            }
  //          //          }
  //          //            if (zipmap.contains(j.m_ZipCode)) {
  //          //              if(!(bdaymap.contains(j.m_Birthday )&& bdaymap(j.m_Birthday).length==1)){
  //          //                if (zipmap(j.m_ZipCode).length == 1) {
  //          //                  if (thetrackerss(j.m_ZipCode).length == 1) {
  //          //                    var abool:Boolean = true
  //          //
  //          //                    for(i <- thetrackerss(j.m_ZipCode)){
  //          //                      if(i.m_Birthday == j.m_Birthday && i.fullName != j.fullName){
  //          //                        abool=false
  //          //                      }
  //          //                    }
  //          //
  //          //                    if(abool) {
  //          //                      outputMap.update(j.fullName, (zipmap(j.m_ZipCode).head))
  //          //                    }
  //          //                }
  //          //              }
  //          //            }
  //          //          }
  //          //        }
  //          //
  //          //        }
  //          //        if(j.m_Birthday!=null && j.m_ZipCode == null){
  //          //          if (bdaymap.contains(j.m_Birthday)) {
  //          //            if (bdaymap(j.m_Birthday).length == 1) {
  //          //              if (thetrackers(j.m_Birthday).length == 1) {
  //          //
  //          //                  outputMap.update(j.fullName, (bdaymap(j.m_Birthday).head))
  //          //
  //          //              }
  //          //            }
  //          //          }
  //          //        }
  //          //
  //          //        if(j.m_Birthday==null && j.m_ZipCode != null){
  //          //          if (zipmap.contains(j.m_ZipCode)) {
  //          //            if (zipmap(j.m_ZipCode).length == 1) {
  //          //              if (thetrackerss(j.m_ZipCode).length == 1) {
  //          //
  //          //                  outputMap.update(j.fullName, (zipmap(j.m_ZipCode).head))
  //          //
  //          //              }
  //          //            }
  //          //
  //          //          }
  //          //        }
  //          ////    for(j <- voterRecords) {
  //          ////      if (bdaymap.contains(j.m_Birthday)) {
  //          ////        if (bdaymap(j.m_Birthday).length == 1) {
  //          ////          if (thetracker(j.m_Birthday, j.m_ZipCode).length == 1) {
  //          ////            //thetracker.update((j.m_Birthday, j.m_ZipCode), thetrackers(j.m_Birthday))
  //          ////            outputMap.update(j.fullName, (bdaymap(j.m_Birthday, j.m_ZipCode).head))
  //          ////          }
  //          ////          //else {
  //          ////           // outputMap -= j.fullName
  //          ////          //}
  //          ////        }
  //          ////      }
  //          //    }
  //          //    println(outputMap)
  //        }
  //      outputMap
  //    }
  def identifyPersons(voterRecords: Seq[VoterRecord], healthRecords: Seq[HealthRecord]): mutable.Map[String, HealthRecord] = {
    //create hashmap
    var myMap: mutable.HashMap[(Date, String), List[HealthRecord]] = mutable.HashMap()
    var bdaymap: mutable.HashMap[Date, List[HealthRecord]] = mutable.HashMap()
    var zipmap: mutable.HashMap[String, List[HealthRecord]] = mutable.HashMap()
    var allbdays: mutable.HashMap[(Date), List[HealthRecord]] = mutable.HashMap()
    var allzips: mutable.HashMap[(String), List[HealthRecord]] = mutable.HashMap()
    var thetracker: mutable.HashMap[(Date, String), VoterRecord] = mutable.HashMap()
    var thetrackers: mutable.HashMap[(Date), VoterRecord] = mutable.HashMap()
    var thetrackerss: mutable.HashMap[(String), VoterRecord] = mutable.HashMap()
    var outputMap: mutable.Map[String, HealthRecord] = mutable.Map()
    var outputtMap: mutable.Map[String, HealthRecord] = mutable.Map()
    var outtielist: List[String] = List()
    var outtieslist: List[String] = List()
    //load in the health records
    for (i <- healthRecords) {
      if (allbdays.contains(i.m_Birthday)) {

        if (!allbdays.contains(i.m_Birthday)) {
          allbdays += (i.m_Birthday -> List(i))
        }
        if (!allzips.contains(i.m_ZipCode)) {
          allzips += (i.m_ZipCode -> List(i))
        }
        if (i.m_ZipCode != null && i.m_Birthday != null) {
          if (myMap.contains(i.m_Birthday, i.m_ZipCode)) {
            myMap.update((i.m_Birthday, i.m_ZipCode), i :: myMap(i.m_Birthday, i.m_ZipCode))
            //          allbdays.update(i.m_Birthday,i :: myMap(i.m_Birthday, i.m_ZipCode))
            //          allzips.update(i.m_ZipCode,i :: myMap(i.m_Birthday, i.m_ZipCode))
          }
          else {
            var aList: List[HealthRecord] = List(i)
            myMap += (i.m_Birthday, i.m_ZipCode) -> aList
          }
        }
        else if (i.m_ZipCode == null && i.m_Birthday != null) {
          if (bdaymap.contains(i.m_Birthday)) {
            bdaymap.update((i.m_Birthday), i :: bdaymap(i.m_Birthday))
          }
          else {
            var aList: List[HealthRecord] = List(i)
            bdaymap += (i.m_Birthday -> aList)
          }
        }
        else if (i.m_ZipCode != null && i.m_Birthday == null) {
          if (zipmap.contains(i.m_ZipCode)) {
            zipmap.update((i.m_ZipCode), i :: zipmap(i.m_ZipCode))
          }
          else {
            var aList: List[HealthRecord] = List(i)
            zipmap += (i.m_ZipCode) -> aList
          }
        }
      }
      println(myMap)
      println(bdaymap)
      println(zipmap)
      println(allbdays)
      println(allzips)
      for (j <- voterRecords) {
        if (j.m_Birthday != null && j.m_ZipCode == null) {
          thetrackers.update(j.m_Birthday, j)
        }
        if (j.m_Birthday == null && j.m_ZipCode != null) {
          thetrackerss.update(j.m_ZipCode, j)
        }
        if (j.m_Birthday != null && j.m_ZipCode != null) {
          if (thetrackers.contains(j.m_Birthday)) {
            thetracker.update((j.m_Birthday, j.m_ZipCode), j)
          }
          if (thetrackerss.contains(j.m_ZipCode)) {
            thetracker.update((j.m_Birthday, j.m_ZipCode), j)
          }
        }
      }
      //          if (j.m_Birthday != null && j.m_ZipCode == null) {
      //            if (bdaymap.contains(j.m_Birthday)) {
      //              if (bdaymap(j.m_Birthday).length == 1 && !outputMap.contains(j.fullName)) {
      //                outputMap(j.fullName) = bdaymap(j.m_Birthday).head
      //              }
      //            }
      //          }
      //          if (j.m_Birthday == null && j.m_ZipCode != null) {
      //            if (zipmap.contains(j.m_ZipCode)) {
      //              if (zipmap(j.m_ZipCode).length == 1 && !outputMap.contains(j.fullName)) {
      //                outputMap(j.fullName) = zipmap(j.m_ZipCode).head
      //              }
      //            }
      //          }
      for (j <- voterRecords) {
        if (myMap.contains(j.m_Birthday, j.m_ZipCode)) {
          if (myMap(j.m_Birthday, j.m_ZipCode).length == 1) {
            if (!outputMap.contains(j.fullName) && !thetracker.contains(j.m_Birthday, j.m_ZipCode) && (!thetrackers.contains(j.m_Birthday)) && !thetrackerss.contains(j.m_ZipCode)) {
              thetracker.update((j.m_Birthday, j.m_ZipCode), j)
              outputMap.update(j.fullName, (myMap(j.m_Birthday, j.m_ZipCode).head))
            }
            else {
              outputMap -= j.fullName
              outputtMap.update(j.fullName, (myMap(j.m_Birthday, j.m_ZipCode).head))
            }
          }
        }
        if (bdaymap.contains(j.m_Birthday)) {
          if (bdaymap(j.m_Birthday).length == 1) {
            if (!outputMap.contains(j.fullName) && !thetracker.contains(j.m_Birthday, j.m_ZipCode) && (!thetrackers.contains(j.m_Birthday))) {
              thetrackers.update((j.m_Birthday), j)
              outputMap.update(j.fullName, (bdaymap(j.m_Birthday).head))
            }
            else {
              outputMap -= j.fullName
              outputtMap.update(j.fullName, (bdaymap(j.m_Birthday).head))
            }
          }
        }
        if (zipmap.contains(j.m_ZipCode)) {
          if (zipmap(j.m_ZipCode).length == 1) {
            if (!outputMap.contains(j.fullName) && !thetracker.contains(j.m_Birthday, j.m_ZipCode) && !thetrackerss.contains(j.m_ZipCode)) {
              thetrackerss.update((j.m_ZipCode), j)
              outputMap.update(j.fullName, (zipmap(j.m_ZipCode).head))
            }
            else {
              outputMap -= j.fullName
              outputtMap.update(j.fullName, (zipmap(j.m_ZipCode).head))
            }
          }
        }
        if (allbdays.contains(j.m_Birthday)) {
          if (allbdays(j.m_Birthday).length == 1) {
            if (!outputMap.contains(j.fullName) && !thetracker.contains(j.m_Birthday, j.m_ZipCode) && (!thetrackers.contains(j.m_Birthday))) {
              thetrackers.update((j.m_Birthday), j)
              outputMap.update(j.fullName, (allbdays(j.m_Birthday).head))
            }
            else {
              outputMap -= j.fullName
              outputtMap.update(j.fullName, (allbdays(j.m_Birthday).head))
            }
          }
        }
        if (allzips.contains(j.m_ZipCode)) {
          if (allzips(j.m_ZipCode).length == 1) {
            if (!outputMap.contains(j.fullName) && !thetracker.contains(j.m_Birthday, j.m_ZipCode) && !thetrackerss.contains(j.m_ZipCode)) {
              thetrackerss.update((j.m_ZipCode), j)
              outputMap.update(j.fullName, (allzips(j.m_ZipCode).head))
            }
            else {
              outputMap -= j.fullName
              outputtMap.update(j.fullName, (allzips(j.m_ZipCode).head))
            }
          }
        }
      }
      for (x <- outputMap.keys) {
        outtielist +:= x
      }
      for (x <- outputtMap.keys) {
        outtieslist +:= x
      }
      var thediff = outtieslist.diff(outtielist)
      for (x <- thediff) {
        if (!outputtMap.contains(x)) {
          outputtMap.remove(x)
        }
      }
      outputMap
      var diff: mutable.Map[String, HealthRecord] = outputtMap -- outputMap.keySet
      println(outputMap)
      println(outtielist)
      println(outtieslist)
      println(thediff)
      println(outputtMap)
      diff
    }




    //          if(j.m_Birthday!= null && j.m_ZipCode==null){
    //            thetrackers.update(j.m_Birthday,j)
    //          }
    //          if(j.m_Birthday== null && j.m_ZipCode!=null){
    //            thetrackerss.update(j.m_ZipCode,j)
    //          }
    //          if (bdaymap.contains(j.m_Birthday)) {
    //            //            if (bdaymap(j.m_Birthday).length > 1) {
    //            //              if ((!outputMap.contains(j.fullName))) {
    //            //                thetrackers += (j.m_Birthday) -> j
    //            //              }
    //            //              else if ((outputMap.contains(j.fullName))) {
    //            //                thetrackers += (j.m_Birthday) -> j
    //            //                outputMap -= j.fullName
    //            //              }
    //            //
    //            if (bdaymap(j.m_Birthday).length == 1) {
    //              //              if (outputMap.contains(j.fullName)) {
    //              //                outputMap -= (j.fullName) -> bdaymap(j.m_Birthday)
    //              //              }
    //              //              if ((!outputMap.contains(j.fullName))) {
    //              //                outputMap += (j.fullName) -> bdaymap(j.m_Birthday)
    //              //              }
    //              if (!outputMap.contains(j.fullName) && !thetrackers.contains(j.m_Birthday)) {
    //                thetrackers += (j.m_Birthday) -> j
    //                outputMap += j.fullName -> bdaymap(j.m_Birthday).head
    //              }
    //              else {
    //                outputMap -= j.fullName
    //              }
    //            }
    //          }
    //          else if (myMap.contains(j.m_Birthday,j.m_ZipCode)) {
    //            if (myMap(j.m_Birthday, j.m_ZipCode).length == 1) {
    //              if (!outputMap.contains(j.fullName) && !thetracker.contains(j.m_Birthday,j.m_ZipCode) && (!thetrackers.contains(j.m_Birthday)) && !thetrackerss.contains(j.m_ZipCode)) {
    //                thetracker += (j.m_Birthday,j.m_ZipCode) -> j
    //                outputMap += j.fullName -> myMap(j.m_Birthday, j.m_ZipCode).head
    //              }
    //              else {
    //                outputMap -= j.fullName
    //              }
    //            }
    //          }
    //
    ////          else if (bdaymap.contains(j.m_Birthday)) {
    //////            if (bdaymap(j.m_Birthday).length > 1) {
    //////              if ((!outputMap.contains(j.fullName))) {
    //////                thetrackers += (j.m_Birthday) -> j
    //////              }
    //////              else if ((outputMap.contains(j.fullName))) {
    //////                thetrackers += (j.m_Birthday) -> j
    //////                outputMap -= j.fullName
    //////              }
    //////
    ////            if (bdaymap(j.m_Birthday).length == 1) {
    //////              if (outputMap.contains(j.fullName)) {
    //////                outputMap -= (j.fullName) -> bdaymap(j.m_Birthday)
    //////              }
    //////              if ((!outputMap.contains(j.fullName))) {
    //////                outputMap += (j.fullName) -> bdaymap(j.m_Birthday)
    //////              }
    ////              if (!outputMap.contains(j.fullName) && !thetrackers.contains(j.m_Birthday)) {
    ////                thetrackers += (j.m_Birthday) -> j
    ////                outputMap += j.fullName -> bdaymap(j.m_Birthday).head
    ////              }
    ////              else {
    ////                outputMap -= j.fullName
    ////              }
    ////            }
    ////          }
    ////          if(thetrackers.contains(j.m_Birthday)||thetracker.contains(j.m_Birthday,j.m_ZipCode)){
    ////            outputMap -= j.fullName
    ////          }
    //          else if (allbdays.contains(j.m_Birthday)) {
    //            //            if (bdaymap(j.m_Birthday).length > 1) {
    //            //              if ((!outputMap.contains(j.fullName))) {
    //            //                thetrackers += (j.m_Birthday) -> j
    //            //              }
    //            //              else if ((outputMap.contains(j.fullName))) {
    //            //                thetrackers += (j.m_Birthday) -> j
    //            //                outputMap -= j.fullName
    //            //              }
    //            //            }
    //            if (allbdays(j.m_Birthday).length == 1) {
    //              //              if (outputMap.contains(j.fullName)) {
    //              //                outputMap -= (j.fullName) -> bdaymap(j.m_Birthday)
    //              //              }
    //              //              if ((!outputMap.contains(j.fullName))) {
    //              //                outputMap += (j.fullName) -> bdaymap(j.m_Birthday)
    //              //              }
    //              if (!outputMap.contains(j.fullName) && !thetrackers.contains(j.m_Birthday) || !thetracker.contains(j.m_Birthday,j.m_ZipCode)) {
    //                thetrackers += (j.m_Birthday) -> j
    //                outputMap += j.fullName -> allbdays(j.m_Birthday).head
    //              }
    //              else if(outputMap.contains(j.fullName) && (thetracker.contains(j.m_Birthday,j.m_ZipCode) || (thetrackers.contains(j.m_Birthday)) || thetrackerss.contains(j.m_ZipCode))){
    //                outputMap -= j.fullName
    //              }
    //            }
    //          }
    //
    //          else if (zipmap.contains(j.m_ZipCode)) {
    ////            if (zipmap(j.m_ZipCode).length > 1) {
    ////              if ((!outputMap.contains(j.fullName)) && (!thetracker.contains(j.fullName))) {
    ////                thetracker += (j.fullName) -> zipmap(j.m_ZipCode).head
    ////              }
    ////            }
    ////            if (zipmap(j.m_ZipCode).length == 1) {
    ////              if (!outputMap.contains(j.fullName)) {
    ////                outputMap += (j.fullName) -> zipmap(j.m_ZipCode).head
    ////              }
    ////              if ((!outputMap.contains(j.fullName)) && (!thetracker.contains(j.fullName))) {
    ////                outputMap += (j.fullName) -> zipmap(j.m_ZipCode).head
    ////              }
    //            //}
    ////            if (zipmap(j.m_ZipCode).length > 1) {
    ////              if ((!outputMap.contains(j.fullName))) {
    ////                thetrackerss += (j.fullName) -> j
    ////              }
    ////              else if ((outputMap.contains(j.fullName))) {
    ////                thetrackerss += (j.m_ZipCode) -> j
    ////                outputMap -= j.fullName
    ////              }
    ////            }
    //            if (zipmap(j.m_ZipCode).length == 1) {
    //              if (!outputMap.contains(j.fullName) && !thetrackerss.contains(j.m_ZipCode)) {
    //                thetrackerss += (j.m_ZipCode) -> j
    //                outputMap += j.fullName -> zipmap(j.m_ZipCode).head
    //              }
    //              else if(outputMap.contains(j.fullName) && (thetracker.contains(j.m_Birthday,j.m_ZipCode) || (thetrackers.contains(j.m_Birthday)) || thetrackerss.contains(j.m_ZipCode))){
    //                outputMap -= j.fullName
    //              }
    //            }
    //          }
    //          else if (allzips.contains(j.m_ZipCode)) {
    //            //            if (bdaymap(j.m_Birthday).length > 1) {
    //            //              if ((!outputMap.contains(j.fullName))) {
    //            //                thetrackers += (j.m_Birthday) -> j
    //            //              }
    //            //              else if ((outputMap.contains(j.fullName))) {
    //            //                thetrackers += (j.m_Birthday) -> j
    //            //                outputMap -= j.fullName
    //            //              }
    //            //            }
    //            if (allzips(j.m_ZipCode).length == 1) {
    //              //              if (outputMap.contains(j.fullName)) {
    //              //                outputMap -= (j.fullName) -> bdaymap(j.m_Birthday)
    //              //              }
    //              //              if ((!outputMap.contains(j.fullName))) {
    //              //                outputMap += (j.fullName) -> bdaymap(j.m_Birthday)
    //              //              }
    //              if (!outputMap.contains(j.fullName) && !thetrackerss.contains(j.m_ZipCode)|| !thetracker.contains(j.m_Birthday,j.m_ZipCode)) {
    //                thetrackerss += (j.m_ZipCode) -> j
    //                outputMap += j.fullName -> allzips(j.m_ZipCode).head
    //              }
    //              else if(outputMap.contains(j.fullName) && (thetracker.contains(j.m_Birthday,j.m_ZipCode) || (thetrackers.contains(j.m_Birthday)) || thetrackerss.contains(j.m_ZipCode))){
    //                outputMap -= j.fullName
    //              }
    //            }
    //          }
    //        }}


    /**
     * Compute a histogram over one of the attributes of HealthRecord
     *
     * @param records   A [[Sequence]] of [[HealthRecord]]s
     * @param attribute Either [[HealthRecordBloodType]]
     *                  or [[HealthRecordAllergies]]
     * @return A key-value pair of each stringified attribute
     *         value and the percentage of the records that
     *         have this value.  The percentage should be
     *         a value in the range (0, 1]
     *
     *         If attribute == HealthRecordBloodType, use [[HealthRecord]]'s
     *         `m_BloodType` field.
     *
     *         If attribute == HealthRecordAllergies, use [[HealthRecord]]'s
     *         `m_DogAllergy`, `m_CatAllergy`, `m_PeanutAllergy`, and
     *         `m_GlutenAllergy` fields.
     *
     *         This function **must** run in O(healthRecords.size)
     */
    def computeHealthRecordDist(records: Seq[HealthRecord], attribute: HealthRecordAttribute): mutable.Map[String, Double] = {
      //var myMap[String,Double]=Map()
      var myMap: mutable.Map[String, Double] = mutable.Map()
      var thelength = records.length
      if (attribute == HealthRecordBloodType) {
        myMap += ("AB+") -> 0.0
        myMap += ("AB-") -> 0.0
        myMap += ("B+") -> 0.0
        myMap += ("A+") -> 0.0
        myMap += ("A-") -> 0.0
        myMap += ("B-") -> 0.0
        myMap += ("O+") -> 0.0
        myMap += ("O-") -> 0.0
        //if (attribute == HealthRecordBloodType) {
        var j = 0
        var myrecord = records(j)
        for (x <- records) {
          if (x.m_BloodType == "AB+") {
            //myMap("AB+") -> (myMap("AB+") + 1)
            myMap.update("AB+", (myMap("AB+") + 1.0))
            //j = j+ 1
          }
          if (x.m_BloodType == "AB-") {
            //myMap("AB-") -> (myMap("AB-") + 1)
            myMap.update("AB-", (myMap("AB-") + 1))
            //j = j+ 1
          }
          if (x.m_BloodType == "A+") {
            //myMap("A+") -> (myMap("A+") + 1)
            myMap.update("A+", (myMap("A+") + 1))
            //j = j+ 1
          }
          if (x.m_BloodType == "B+") {
            //myMap("B+") -> (myMap("B+") + 1)
            myMap.update("B+", (myMap("B+") + 1))
            //j = j+ 1
          }
          if (x.m_BloodType == "A-") {
            //myMap("A-") -> (myMap("A-") + 1)
            myMap.update("A-", (myMap("A-") + 1))
            //j = j+ 1
          }
          if (x.m_BloodType == "B-") {
            //myMap("B-") -> (myMap("B-") + 1)
            myMap.update("B-", (myMap("B-") + 1))
            //j = j+ 1
          }
          if (x.m_BloodType == "O-") {
            // myMap("O+") -> (myMap("O+") + 1)
            myMap.update("O-", (myMap("O-") + 1))
            //j = j+ 1
          }
          if (x.m_BloodType == "O+") {
            //myMap("O+") -> (myMap("O+") + 1)
            myMap.update("O+", (myMap("O+") + 1))
            //j = j+ 1
          }
          //j = j+ 1
        }
      }
      if (attribute == HealthRecordAllergies) {
        myMap += ("Dog") -> 0.0
        myMap += ("Cat") -> 0.0
        myMap += ("Peanut") -> 0.0
        myMap += ("Gluten") -> 0.0
        //var j = 0
        //var myrecord = records(j)
        for (x <- records) {
          if (x.m_DogAllergy.equals(true)) {
            //myMap("Dog") -> (myMap("Dog") + 1)
            myMap.update("Dog", (myMap("Dog") + 1))

          }
          if (x.m_CatAllergy.equals(true)) {
            //myMap("") -> (myMap("") + 1)
            myMap.update("Cat", (myMap("Cat") + 1))
            //j = j+1
          }
          if (x.m_PeanutAllergy.equals(true)) {
            //myMap("Peanut") -> (myMap("Peanut") + 1)
            myMap.update("Peanut", (myMap("Peanut") + 1))
            //j = j+1
          }
          if (x.m_GlutenAllergy.equals(true)) {
            //myMap("Gluten") -> (myMap("Gluten") + 1)
            myMap.update("Gluten", myMap("Gluten") + 1)
            //j = j+1
          }
          //j = j+1
        }
      }
      for (x <- myMap.keys) {
        if (x == "N/A") {
          thelength = thelength - 1
        }
        else {
          myMap.update(x, myMap(x) / thelength)
        }
      }
      myMap
    }
  }
}

