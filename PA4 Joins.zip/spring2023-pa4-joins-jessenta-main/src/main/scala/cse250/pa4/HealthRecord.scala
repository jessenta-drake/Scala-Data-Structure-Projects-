/**
 * cse250.pa4.HealthRecord.scala
 *
 * Copyright 2022 Oliver Kennedy (okennedy@buffalo.edu)
 *           2022 Eric Mikida (epmikida@buffalo.edu)
 *           2021 Andrew Hughes (ahughes6@buffalo.edu)
 *
 * This work is licensed under the Creative Commons
 * Attribution-NonCommercial-ShareAlike 4.0 International License.
 * To view a copy of this license, visit
 * http://creativecommons.org/licenses/by-nc-sa/4.0/.
 *
 */
package cse250.pa4

import java.util.Date

case class HealthRecord(m_Birthday: Date,
                        m_ZipCode: String,
                        m_BloodType: String,
                        m_DogAllergy: Boolean,
                        m_CatAllergy: Boolean,
                        m_PeanutAllergy: Boolean,
                        m_GlutenAllergy: Boolean)

sealed trait HealthRecordAttribute

case object HealthRecordBloodType extends HealthRecordAttribute
case object HealthRecordAllergies extends HealthRecordAttribute