/**
 * cse250.pa4.DataToolsTests
 *
 * Copyright 2022 Oliver Kennedy (okennedy@buffalo.edu)
 *           2022 Eric Mikida (epmikida@buffalo.edu)
 *           2021 Andrew Hughes (ahughes6@buffalo.edu)
 *
 * This work is licensed under the Creative Commons
 * Attribution-NonCommercial-ShareAlike 4.0 International License.
 * To view a copy of this license, visit
 * http://creativecommons.org/licenses/by-nc-sa/4.0/.
 */
package cse250.pa4

import org.scalatest.flatspec.AnyFlatSpec

import java.io.File

/**
 * These tests are provided **to get you started**.  Passing these tests
 * does not guarantee that you will get a good grade on the project.  It
 * doesn't even guarantee that you will get a non-zero grade.
 *
 * **Add your own tests!**
 */
class DataToolsTests extends AnyFlatSpec
{
  /**
   * Method to compare doubles with a specified degree of precision.
   */
  val EPSILON: Double = 0.0001

  def compareDoubles(d1: Double, d2: Double): Boolean = {
    Math.abs(d1 - d2) < EPSILON
  }
  "loadHealthRecords" must "Load HealthRecords" in
  {
    val records = DataTools.loadHealthRecords(
      new File("src/test/resources/Health-Records-10.csv")
    )

    assert(records(0).m_ZipCode != "Zip Code", "Accidentally loading the header row")
    assert(records.size == 10, "Not loading the right number of records")

    assert(records.map { _.m_Birthday } contains DataTools.parseDate("11/17/1978"))
    assert(records.map { _.m_ZipCode } contains "14261")
    assert(records.filter { _.m_ZipCode == "14261" }
                  .head.m_DogAllergy == true)
    assert(records.filter { _.m_ZipCode == "14261" }
                  .head.m_GlutenAllergy == false)
  }

  "loadHealthRecords" must "Load HealthRecordss" in
    {
//      val records = DataTools.loadHealthRecords(
//        new File("src/test/resources/Health-Records-10.csv")
//      )
//      //assert(records.head.m_Birthday != "Birthday", "Accidentally loading the header row")
//      //assert(records.head.m_BloodType != "BloodType", "Accidentally loading the header row")
//      //assert(records.head.m_ZipCode != "Zip Code", "Accidentally loading the header row")
//      //assert(records.head.m_DogAllergy != "DogAllergy", "Accidentally loading the header row")
//      //assert(records.head.m_GlutenAllergy != "GlutenAllergy", "Accidentally loading the header row")
//      //assert(records.head.m_CatAllergy != "CatAllergy", "Accidentally loading the header row")
//      //assert(records.head.m_PeanutAllergy != "PeanutAllergy", "Accidentally loading the header row")
//
//      assert(records.size == 11, "Not loading the right number of records")
//
//
//      assert(records.head.m_Birthday == DataTools.parseDate("9/23/1996") )
//      assert(records.head.m_ZipCode.equals("14209"))
//      assert(records.head.m_BloodType.equals("A+"))
//      assert(!records.head.m_DogAllergy)
//      assert(records.head.m_CatAllergy)
//      assert(records.head.m_PeanutAllergy)
//      assert(!records.head.m_GlutenAllergy)
//
//
//      assert(records(1).m_Birthday == DataTools.parseDate("3/16/1986") )
//      assert(records(1).m_ZipCode.equals("14216"))
//      assert(records(1).m_BloodType.equals("A-"))
//      assert(records(1).m_DogAllergy)
//      assert(!records(1).m_CatAllergy)
//      assert(!records(1).m_PeanutAllergy)
//      assert(!records(1).m_GlutenAllergy)
//
//      assert(records(2).m_Birthday == DataTools.parseDate("6/10/1968") )
//      assert(records(2).m_ZipCode.equals("14214"))
//      assert(records(2).m_BloodType.equals("A-"))
//      assert(!records(2).m_DogAllergy)
//      assert(records(2).m_CatAllergy)
//      assert(!records(2).m_PeanutAllergy)
//      assert(!records(2).m_GlutenAllergy)
//
//      assert(records(3).m_Birthday == DataTools.parseDate("7/12/1970") )
//      assert(records(3).m_ZipCode.equals("14210"))
//      assert(records(3).m_BloodType.equals("AB+"))
//      assert(!records(3).m_DogAllergy)
//      assert(!records(3).m_CatAllergy)
//      assert(records(3).m_PeanutAllergy)
//      assert(!records(3).m_GlutenAllergy)
//
//      assert(records(4).m_Birthday == DataTools.parseDate("8/31/1988") )
//      assert(records(4).m_ZipCode.equals("14213"))
//      assert(records(4).m_BloodType.equals("AB-"))
//      assert(records(4).m_DogAllergy)
//      assert(!records(4).m_CatAllergy)
//      assert(records(4).m_PeanutAllergy)
//      assert(records(4).m_GlutenAllergy)
//
//      assert(records(5).m_Birthday == DataTools.parseDate("3/14/1987") )
//      assert(records(5).m_ZipCode.equals("14212"))
//      assert(records(5).m_BloodType.equals("O+"))
//      assert(!records(5).m_DogAllergy)
//      assert(!records(5).m_CatAllergy)
//      assert(!records(5).m_PeanutAllergy)
//      assert(!records(5).m_GlutenAllergy)
//
//      assert(records(6).m_Birthday == DataTools.parseDate("11/17/1978") )
//      assert(records(6).m_ZipCode.equals("14261"))
//      assert(records(6).m_BloodType.equals("AB+"))
//      assert(records(6).m_DogAllergy)
//      assert(records(6).m_CatAllergy)
//      assert(!records(6).m_PeanutAllergy)
//      assert(!records(6).m_GlutenAllergy)
//
//      assert(records(7).m_Birthday == DataTools.parseDate("11/15/1973") )
//      assert(records(7).m_ZipCode.equals("14222"))
//      assert(records(7).m_BloodType.equals("B+"))
//      assert(records(7).m_DogAllergy)
//      assert(records(7).m_CatAllergy)
//      assert(!records(7).m_PeanutAllergy)
//      assert(records(7).m_GlutenAllergy)
//
//      assert(records(8).m_Birthday == DataTools.parseDate("2/20/1957") )
//      assert(records(8).m_ZipCode.equals("14223"))
//      assert(records(8).m_BloodType.equals("B-"))
//      assert(records(8).m_DogAllergy)
//      assert(records(8).m_CatAllergy)
//      assert(records(8).m_PeanutAllergy)
//      assert(!records(8).m_GlutenAllergy)
//
//      assert(records(9).m_Birthday == DataTools.parseDate("6/21/1986") )
//      assert(records(9).m_ZipCode.equals("14201"))
//      assert(records(9).m_BloodType.equals("A+"))
//      assert(!records(9).m_DogAllergy)
//      assert(!records(9).m_CatAllergy)
//      assert(records(9).m_PeanutAllergy)
//      assert(records(9).m_GlutenAllergy)
//
//      assert(records(10).m_Birthday == DataTools.parseDate("9/23/1996"))
//      assert(records(10).m_ZipCode.equals("14209"))
//      assert(records(10).m_BloodType.equals("N/A"))
//      assert(records(10).m_DogAllergy)
//      assert(!records(10).m_CatAllergy)
//      assert(records(10).m_PeanutAllergy)
//      assert(!records(10).m_GlutenAllergy)
//    }
//
////  "loadVoterRecords" must "Load VoterRecords" in
////  {
////    val records = DataTools.loadVoterRecords(
////      new File("src/test/resources/Voter-Records-10.csv")
////    )
////
////    assert(records(0).m_FirstName != "First Name", "Accidentally loading the header row")
////    assert(records.size == 10, "Not loading the right number of records")
////
////    assert(records.map { _.m_FirstName} contains "LILY")
////    assert(records.map { _.m_FirstName} contains "KARA")
////    assert(records.map { _.m_FirstName} contains "DEWEY")
////  }
val records = DataTools.loadHealthRecords(
  new File("src/test/resources/Health-Records-10.csv")
)
      assert(records.size == 11, "Not loading the right number of records")
      assert(records.head.m_Birthday == DataTools.parseDate("9/23/1996") )
      assert(records.head.m_ZipCode.equals("14209"))
      assert(records.head.m_BloodType.equals("A+"))
      assert(!records.head.m_DogAllergy)
      assert(records.head.m_CatAllergy)
      assert(records.head.m_PeanutAllergy)
      assert(!records.head.m_GlutenAllergy)

      assert(records(1).m_Birthday == DataTools.parseDate("3/16/1986") )
      assert(records(1).m_ZipCode.equals("14216"))
      assert(records(1).m_BloodType.equals("A-"))
      assert(records(1).m_DogAllergy)
      assert(!records(1).m_CatAllergy)
      assert(!records(1).m_PeanutAllergy)
      assert(!records(1).m_GlutenAllergy)

      assert(records(2).m_Birthday == DataTools.parseDate("6/10/1968") )
      assert(records(2).m_ZipCode.equals("14214"))
      assert(records(2).m_BloodType.equals("A-"))
      assert(!records(2).m_DogAllergy)
      assert(records(2).m_CatAllergy)
      assert(!records(2).m_PeanutAllergy)
      assert(!records(2).m_GlutenAllergy)

      assert(records(3).m_Birthday == DataTools.parseDate("7/12/1970") )
      assert(records(3).m_ZipCode.equals("14210"))
      assert(records(3).m_BloodType.equals("AB+"))
      assert(!records(3).m_DogAllergy)
      assert(!records(3).m_CatAllergy)
      assert(records(3).m_PeanutAllergy)
      assert(!records(3).m_GlutenAllergy)

      assert(records(4).m_Birthday == DataTools.parseDate("8/31/1988") )
      assert(records(4).m_ZipCode.equals("14213"))
      assert(records(4).m_BloodType.equals("AB-"))
      assert(records(4).m_DogAllergy)
      assert(!records(4).m_CatAllergy)
      assert(records(4).m_PeanutAllergy)
      assert(records(4).m_GlutenAllergy)

      assert(records(5).m_Birthday == DataTools.parseDate("3/14/1987") )
      assert(records(5).m_ZipCode.equals("14212"))
      assert(records(5).m_BloodType.equals("O+"))
      assert(!records(5).m_DogAllergy)
      assert(!records(5).m_CatAllergy)
      assert(!records(5).m_PeanutAllergy)
      assert(!records(5).m_GlutenAllergy)

      assert(records(6).m_Birthday == DataTools.parseDate("11/17/1978") )
      assert(records(6).m_ZipCode.equals("14261"))
      assert(records(6).m_BloodType.equals("AB+"))
      assert(records(6).m_DogAllergy)
      assert(records(6).m_CatAllergy)
      assert(!records(6).m_PeanutAllergy)
      assert(!records(6).m_GlutenAllergy)

      assert(records(7).m_Birthday == DataTools.parseDate("11/15/1973") )
      assert(records(7).m_ZipCode.equals("14222"))
      assert(records(7).m_BloodType.equals("B+"))
      assert(records(7).m_DogAllergy)
      assert(records(7).m_CatAllergy)
      assert(!records(7).m_PeanutAllergy)
      assert(records(7).m_GlutenAllergy)

      assert(records(8).m_Birthday == DataTools.parseDate("2/20/1957") )
      assert(records(8).m_ZipCode.equals("14223"))
      assert(records(8).m_BloodType.equals("B-"))
      assert(records(8).m_DogAllergy)
      assert(records(8).m_CatAllergy)
      assert(records(8).m_PeanutAllergy)
      assert(!records(8).m_GlutenAllergy)

      assert(records(9).m_Birthday == DataTools.parseDate("6/21/1986") )
      assert(records(9).m_ZipCode.equals("14201"))
      assert(records(9).m_BloodType.equals("A+"))
      assert(!records(9).m_DogAllergy)
      assert(!records(9).m_CatAllergy)
      assert(records(9).m_PeanutAllergy)
      assert(records(9).m_GlutenAllergy)

      assert(records(10).m_Birthday == DataTools.parseDate("9/23/1996"))
      assert(records(10).m_ZipCode==null)
      assert(records(10).m_BloodType.equals("AB+"))
      assert(records(10).m_DogAllergy)
      assert(!records(10).m_CatAllergy)
      assert(records(10).m_PeanutAllergy)
      assert(!records(10).m_GlutenAllergy)
    }
    "loadVoterRecords" must "Load VoterRecords" in
    {
      val records = DataTools.loadVoterRecords(
        new File("src/test/resources/Voter-Records-10.csv")
      )

      assert(records(0).m_FirstName != "First Name", "Accidentally loading the header row")
      assert(records.size == 10, "Not loading the right number of records")

      assert(records.map { _.m_FirstName} contains "LILY")
      assert(records.map { _.m_FirstName} contains "KARA")
      assert(records.map { _.m_FirstName} contains "DEWEY")
    }

  "loadVoterRecords" must "Load VoterRecordss" in
    {
val records = DataTools.loadVoterRecords(
  new File("src/test/resources/Voter-Records-10.csv")
)
      assert(records.size == 11, "Not loading the right number of records")
      assert(records.head.m_Birthday == DataTools.parseDate("11/17/1978"))
      assert(records.head.m_ZipCode.equals("14261"))

      assert(records.head.m_FirstName.equals("SIMON"))
      assert(records.head.m_LastName.equals("DURAN"))

      assert(records(1).m_Birthday == DataTools.parseDate("9/23/1996"))
      assert(records(1).m_ZipCode.equals("14209"))
      assert(records(1).m_FirstName.equals("EMELIA"))
      assert(records(1).m_LastName.equals("STEWART"))

      assert(records(2).m_Birthday == DataTools.parseDate("7/12/1970"))
      assert(records(2).m_ZipCode.equals("14210"))
      assert(records(2).m_FirstName.equals("NIA"))
      assert(records(2).m_LastName.equals("GONZALEZ"))

      assert(records(3).m_Birthday == DataTools.parseDate("3/16/1986"))
      assert(records(3).m_ZipCode.equals("14216"))
      assert(records(3).m_FirstName.equals("VIOLET"))
      assert(records(3).m_LastName.equals("HARMON"))

      assert(records(4).m_Birthday == DataTools.parseDate("6/21/1986"))
      assert(records(4).m_ZipCode.equals("14201"))
      assert(records(4).m_FirstName.equals("EDWIN"))
      assert(records(4).m_LastName.equals("SUTTON"))

      assert(records(5).m_Birthday == DataTools.parseDate("8/31/1988"))
      assert(records(5).m_ZipCode.equals("14213"))
      assert(records(5).m_FirstName.equals("LILY"))
      assert(records(5).m_LastName.equals("BAKER"))

      assert(records(6).m_Birthday == DataTools.parseDate("11/15/1973"))
      assert(records(6).m_ZipCode.equals("14222"))
      assert(records(6).m_FirstName.equals("MILO"))
      assert(records(6).m_LastName.equals("ORTIZ"))

      assert(records(7).m_Birthday == DataTools.parseDate("6/10/1968"))
      assert(records(7).m_ZipCode.equals("14214"))
      assert(records(7).m_FirstName.equals("KARA"))
      assert(records(7).m_LastName.equals("OLIVER"))

      assert(records(8).m_Birthday == DataTools.parseDate("2/20/1957"))
      assert(records(8).m_ZipCode.equals("14223"))
      assert(records(8).m_FirstName.equals("BRANDON"))
      assert(records(8).m_LastName.equals("GARDNER"))

      assert(records(9).m_Birthday == DataTools.parseDate("3/14/1987"))
      assert(records(9).m_ZipCode.equals("14212"))
      assert(records(9).m_FirstName.equals("DEWEY"))
      assert(records(9).m_LastName.equals("WILSON"))

      assert(records(10).m_Birthday == DataTools.parseDate("9/23/1996"))
      assert(records(10).m_ZipCode==null)
      assert(records(10).m_FirstName.equals("JOHN"))
      assert(records(10).m_LastName.equals("CENA"))
    }
  "identifyPersons" must "Identify Persons" in
  {
    val health = DataTools.loadHealthRecords(
      new File("src/test/resources/Health-Records-10.csv")
    )
    val voter = DataTools.loadVoterRecords(
      new File("src/test/resources/Voter-Records-10.csv")
    )

    val deanonymized = DataTools.identifyPersons(voter, health)

    /*  The 10-row test data has matches for **every** record.  This
        will not usually be the case! */
    for(v <- voter) {
      assert(deanonymized.keySet contains v.fullName)
    }

    assert(deanonymized("NIA GONZALEZ").m_BloodType == "AB+")
    assert(deanonymized("NIA GONZALEZ").m_DogAllergy == false)
    assert(deanonymized("NIA GONZALEZ").m_CatAllergy == false)
    assert(deanonymized("NIA GONZALEZ").m_PeanutAllergy == true)
    assert(deanonymized("NIA GONZALEZ").m_GlutenAllergy == false)
  }
  "identifyPersons" must "Identify Personss" in {
    val health = DataTools.loadHealthRecords(
      new File("src/test/resources/Health-Records-10.csv")
    )
    val voter = DataTools.loadVoterRecords(
      new File("src/test/resources/Voter-Records-10.csv")
    )
    val deanonymized = DataTools.identifyPersons(voter, health)
    assert(deanonymized.size==9)

    assert(!deanonymized.contains("EMELIA STEWART"))
    assert(!deanonymized.contains("JOHN CENA"))

    assert(deanonymized("SIMON DURAN").m_BloodType == "AB+")
    assert(deanonymized("SIMON DURAN").m_DogAllergy)
    assert(deanonymized("SIMON DURAN").m_CatAllergy)
    assert(!deanonymized("SIMON DURAN").m_PeanutAllergy)
    assert(!deanonymized("SIMON DURAN").m_GlutenAllergy)

    assert(deanonymized("NIA GONZALEZ").m_BloodType == "AB+")
    assert(!deanonymized("NIA GONZALEZ").m_DogAllergy)
    assert(!deanonymized("NIA GONZALEZ").m_CatAllergy)
    assert(deanonymized("NIA GONZALEZ").m_PeanutAllergy)
    assert(!deanonymized("NIA GONZALEZ").m_GlutenAllergy)

    assert(deanonymized("VIOLET HARMON").m_BloodType == "A-")
    assert(deanonymized("VIOLET HARMON").m_DogAllergy)
    assert(!deanonymized("VIOLET HARMON").m_CatAllergy)
    assert(!deanonymized("VIOLET HARMON").m_PeanutAllergy)
    assert(!deanonymized("VIOLET HARMON").m_GlutenAllergy)

    assert(deanonymized("EDWIN SUTTON").m_BloodType == "A+")
    assert(!deanonymized("EDWIN SUTTON").m_DogAllergy)
    assert(!deanonymized("EDWIN SUTTON").m_CatAllergy)
    assert(deanonymized("EDWIN SUTTON").m_PeanutAllergy)
    assert(deanonymized("EDWIN SUTTON").m_GlutenAllergy)

    assert(deanonymized("LILY BAKER").m_BloodType == "AB-")
    assert(deanonymized("LILY BAKER").m_DogAllergy)
    assert(!deanonymized("LILY BAKER").m_CatAllergy)
    assert(deanonymized("LILY BAKER").m_PeanutAllergy)
    assert(deanonymized("LILY BAKER").m_GlutenAllergy)

    assert(deanonymized("MILO ORTIZ").m_BloodType == "B+")
    assert(deanonymized("MILO ORTIZ").m_DogAllergy)
    assert(deanonymized("MILO ORTIZ").m_CatAllergy)
    assert(!deanonymized("MILO ORTIZ").m_PeanutAllergy)
    assert(deanonymized("MILO ORTIZ").m_GlutenAllergy)

    assert(deanonymized("KARA OLIVER").m_BloodType == "A-")
    assert(!deanonymized("KARA OLIVER").m_DogAllergy)
    assert(deanonymized("KARA OLIVER").m_CatAllergy)
    assert(!deanonymized("KARA OLIVER").m_PeanutAllergy)
    assert(!deanonymized("KARA OLIVER").m_GlutenAllergy)

    assert(deanonymized("BRANDON GARDNER").m_BloodType == "B-")
    assert(deanonymized("BRANDON GARDNER").m_DogAllergy)
    assert(deanonymized("BRANDON GARDNER").m_CatAllergy)
    assert(deanonymized("BRANDON GARDNER").m_PeanutAllergy)
    assert(!deanonymized("BRANDON GARDNER").m_GlutenAllergy)

    assert(deanonymized("DEWEY WILSON").m_BloodType == "O+")
    assert(!deanonymized("DEWEY WILSON").m_DogAllergy)
    assert(!deanonymized("DEWEY WILSON").m_CatAllergy)
    assert(!deanonymized("DEWEY WILSON").m_PeanutAllergy)
    assert(!deanonymized("DEWEY WILSON").m_GlutenAllergy)
  }
  "computeHealthRecordDist" must "Compute Health Record Dist" in {
    val notokeric = DataTools.loadHealthRecords(new File("src/test/resources/Health-Records-10.csv"))
    val okeric = DataTools.computeHealthRecordDist(notokeric,HealthRecordBloodType)
    val okerica = DataTools.computeHealthRecordDist(notokeric,HealthRecordAllergies)
    println(okeric)
    print(okerica)
    assert(compareDoubles(okeric("A+"),0.18181818181))
    assert(compareDoubles(okeric("A-"),0.18181818181))
    assert(compareDoubles(okeric("B+"),0.0909090909))
    assert(compareDoubles(okeric("B-"),0.0909090909))
    assert(compareDoubles(okeric("AB+"),0.27272727272))
    assert(compareDoubles(okeric("AB-"),0.0909090909))
    assert(compareDoubles(okeric("O+"),0.0909090909))

    assert(compareDoubles(okerica("Peanut"),0.54545454545))
    assert(compareDoubles(okerica("Gluten"),0.27272727272))
    assert(compareDoubles(okerica("Cat"),0.45454545454))
    assert(compareDoubles(okerica("Dog"),0.54545454545))



  }
  "identifyPersons" must "IdentifyPersonsss" in {
  val health = DataTools.loadHealthRecords(
    new File("src/test/resources/hh.csv")
  )
  val voter = DataTools.loadVoterRecords(
    new File("src/test/resources/vv.csv")
  )
  val deanonymized = DataTools.identifyPersons(voter, health)

  assert(deanonymized.size ==0)


}
}
