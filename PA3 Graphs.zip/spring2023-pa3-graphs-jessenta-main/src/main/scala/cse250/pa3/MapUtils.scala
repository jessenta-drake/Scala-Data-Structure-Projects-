package cse250.pa3
/**
 * cse250.pa3.Edge
 *
 * Copyright 2022 Oliver Kennedy (okennedy@buffalo.edu)
 *           2022 Eric Mikida (epmikida@buffalo.edu)
 * 
 * Based on work 
 * Copyright 2021 Andrew Hughes (ahughes@buffalo.edu)
 *
 * This work is licensed under the Creative Commons
 * Attribution-NonCommercial-ShareAlike 4.0 International License.
 * To view a copy of this license, visit
 * http://creativecommons.org/licenses/by-nc-sa/4.0/.
 *
 */

import scala.collection.mutable
import scala.math.BigDecimal
object MapUtils
{

  /**
   * Compute the outgoing links from each intersection in the graph.
   * @param    graph     The intersections and links for a map
   * @return             A lookup table of all of the outgoing edges for each intersection.
   * 
   * This function should run in O(graph.edges.size)
   */
  def computeOutgoingEdges(graph: StreetGraph): mutable.Map[String, mutable.Seq[Edge]] = {
    mutable.Map.from(graph.edges.groupBy(_.from.id))
  }
  /**
   * Compute the path between two intersections that passes through the fewest intersections.
   * @param    graph         The intersections and links for a map
   * @param    outgoingEdges A lookup table of all of the outgoing edges for each intersection.
   * @param    from          The ID of the intersection to route from
   * @param    to            The ID of the intersection to route to
   * @return                 The shortest path needed to get from [[from]] to [[to]]
   * 
   * This function should run in O(graph.edges.size + graph.intersections.size)
    */
    def pathWithFewestIntersections(graph: StreetGraph, outgoingEdges: mutable.Map[String, mutable.Seq[Edge]], from: String, to: String): List[Edge] =
    {
      var thePath:List[Edge] =List()
      var mygraph =computeOutgoingEdges(graph)
      val myQueue: mutable.Queue[String] = mutable.Queue()
      var theHash= new mutable.HashMap[String,Edge]
      myQueue.enqueue(from)
      val theExploredIntersections: mutable.Set[String] = mutable.Set()
      theExploredIntersections.add(from)
      while(myQueue.nonEmpty) {
        var tobeExp = myQueue.dequeue()
        if (tobeExp.equals(to)) {
          while (!tobeExp.equals(from)) {
            thePath = theHash(tobeExp) :: thePath
            tobeExp = theHash(tobeExp).from.id
          }
        }
        if (outgoingEdges.contains(tobeExp)) {
          for (z <- outgoingEdges(tobeExp)) {
            if (!theExploredIntersections.contains(z.to.id)) {
              myQueue.enqueue(z.to.id)
              theExploredIntersections.add(z.to.id)
              theHash += (z.to.id -> z)
            }
          }
        }
      }
        thePath
    }

  /**
   * Compute the path between two intersections that passes through the fewest intersections.
   * @param    graph         The intersections and links for a map
   * @param    outgoingEdges A lookup table of all o f the outgoing edges for each intersection.
   * @param    from          The ID of the intersection to route from
   * @param    to            The ID of the intersection to route to
   * @return                 The shortest path needed to get from [[from]] to [[to]]
   * 
   * This function should run in O(graph.edges.size * log(graph.intersections.size))
   */
      def pathWithShortestDistance(graph: StreetGraph, outgoingEdges: mutable.Map[String, mutable.Seq[Edge]], from: String, to: String): List[Edge] =
      {
        var thePath:List[Edge] =List()
       // var mygraph =computeOutgoingEdges(graph)
        //val myQueue: mutable.Queue[String] = mutable.Queue()
       val queue = PriorityQueueHelper.create[(String,Double)]{
       (x,y)=>Ordering[Double].compare(y._2,x._2)
    }
//        val queue =  mutable.PriorityQueue.empty[(String,Double)](
//          new Ordering[(String,Double)] {
//            def compare(x: (String,Double), y: (String,Double)): Int =
//            {
//              if(y._2 < x._2){
//                return -1
//              }
//              if(x._2 < y._2){
//                return 1
//              }
//              return 0
//            }
//          }
//        )
        var theHash= new mutable.HashMap[String,Edge]
        queue.enqueue((from,0.0))
        val theExploredIntersections: mutable.Set[String] = mutable.Set()
        theExploredIntersections.add(from)
        var tobeExp = ("",0.0)
        while(queue.nonEmpty) {
          tobeExp = queue.dequeue()
        if (tobeExp._1.equals(to)) {
          while (!tobeExp._1.equals(from)) {
              thePath = theHash(tobeExp._1) :: thePath
              tobeExp = (theHash(tobeExp._1).from.id,tobeExp._2)
              }
        }
          if (outgoingEdges.contains(tobeExp._1)) {
            for (z <- outgoingEdges(tobeExp._1)) {
              if (!theExploredIntersections.contains(z.to.id)) {
                queue.enqueue((z.to.id, (BigDecimal(tobeExp._2+z.from.distanceTo(z.to)).setScale(3, BigDecimal.RoundingMode.HALF_UP).toDouble)))
                theExploredIntersections.add(z.to.id)
                theHash += (z.to.id -> z)
              }
            }
          }
        }
        thePath
      }




  /**
   * Generate a human-readable name for an intersection
   */
  def nameOfIntersection(id: String, outgoingEdges: mutable.Map[String, mutable.Seq[Edge]]): String =
  {
    id + " @ " + (
      outgoingEdges(id).map { _.streetName }.toSet.toSeq match {
        case Seq() => "Empty Intersection"
        case Seq(a) => s"${a}"
        case Seq(a, b) => s"${a} and ${b}"
        case other     => s"${other.drop(1).mkString(", ")}, and ${other.head}"
      }
    )

  }
}