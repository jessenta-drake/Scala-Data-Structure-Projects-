package cse250.pa3
/**
 * cse250.pa3.MapUtilsTests
 *
 * Copyright 2022 Oliver Kennedy (okennedy@buffalo.edu)
 *           2022 Eric Mikida (epmikida@buffalo.edu)
 *
 * Based on work 
 * Copyright 2021 Andrew Hughes (ahughes@buffalo.edu)
 *
 * This work is licensed under the Creative Commons
 * Attribution-NonCommercial-ShareAlike 4.0 International License.
 * To view a copy of this license, visit
 * http://creativecommons.org/licenses/by-nc-sa/4.0/.
 *
 * Submission author
 * UBIT:
 * Person#:
 *
 * Collaborators (include UBIT name of each, comma separated):
 * UBIT:
 */

import org.scalatest.flatspec.AnyFlatSpec

class MapUtilsTests extends AnyFlatSpec {

  val graph = StreetGraph.load("data/buffalo_map.xml")

  behavior of "MapUtilsTests"

  it must "load data correctly" in {
    assert(graph.intersections.size == 282843)
    assert(graph.edges.size == 38636)
  }

  it must "generate adjacency list" in {
    //nodes are intersections

    val nodeone = new Intersection("newone", 3, 1)
    val nodetwo = new Intersection("newtwo", 1, 3)
    val nodethree = new Intersection("newthree", 3, 2)
    val nodefour = new Intersection("newfour", 2, 3)

    val edgeone = new Edge(nodeone, nodetwo, "edgeone")
    val edgetwo = new Edge(nodetwo, nodeone, "edgetwo")
    val edgethree = new Edge(nodetwo, nodethree, "edgethree")
    val edgefour = new Edge(nodethree, nodetwo, "edgefour")
    val edgefive = new Edge(nodethree, nodefour, "edgefive")
    val edgesix = new Edge(nodefour, nodethree, "edgesix")
    val edgeseven = new Edge(nodefour, nodeone, "edgeseven")
    val edgeeight = new Edge(nodeone, nodefour, "edgeeight")
    val edgenine = new Edge(nodeone, nodethree, "edgenine")
    val edgeten = new Edge(nodethree, nodeone, "edgeten")

    val myGraph = new StreetGraph
    myGraph.intersections += nodeone.id -> nodeone
    myGraph.intersections += nodetwo.id -> nodetwo
    myGraph.intersections += nodethree.id -> nodethree
    myGraph.intersections += nodefour.id -> nodefour

    myGraph.edges.append(edgeone)
    myGraph.edges.append(edgetwo)
    myGraph.edges.append(edgethree)
    myGraph.edges.append(edgefour)
    myGraph.edges.append(edgefive)
    myGraph.edges.append(edgesix)
    myGraph.edges.append(edgeseven)
    myGraph.edges.append(edgeeight)
    myGraph.edges.append(edgenine)
    myGraph.edges.append(edgeten)

    val jess = MapUtils.computeOutgoingEdges(myGraph)
    val d = jess(nodeone.id)
    val r = jess(nodetwo.id)
    val a = jess(nodethree.id)
    val k = jess(nodefour.id)
    assert(d.size == 3)
    assert(d.contains(edgeone))
    assert(d.contains(edgeeight))
    assert(d.contains(edgenine))
    assert(r.size == 2)
    assert(r.contains(edgetwo))
    assert(r.contains(edgethree))
    assert(a.size == 3)
    assert(a.contains(edgefour))
    assert(a.contains(edgefive))
    assert(a.contains(edgeten))
    assert(k.size == 2)
    assert(k.contains(edgesix))
    assert(k.contains(edgeseven))

  }

  it must "fewest intersections" in {
    val nodeone = new Intersection("newone", 1, 7)
    val nodetwo = new Intersection("newtwo", 2, 6)
    val nodethree = new Intersection("newthree", 3, 5)
    val nodefour = new Intersection("newfour", 4, 4)
    val nodefive = new Intersection("newfive", 5, 3)
    val nodesix = new Intersection("newsix", 6, 2)
    val nodeseven = new Intersection("newseven", 7, 1)

    val edgeone = new Edge(nodeone, nodetwo, "edgeone")
    val edgetwo = new Edge(nodeone, nodethree, "edgetwo")

    val edgethree = new Edge(nodetwo, nodeone, "edgethree")
    val edgefour = new Edge(nodetwo, nodethree, "edgefour")

    val edgefive = new Edge(nodethree, nodeone, "edgefive")
    val edgesix = new Edge(nodethree, nodetwo, "edgesix")
    val edgeseven = new Edge(nodethree, nodefour, "edgeseven")

    val edgeeight = new Edge(nodefour, nodethree, "edgeeight")
    val edgenine = new Edge(nodefour, nodefive, "edgenine")
    val edgeten = new Edge(nodefour, nodesix, "edgeten")

    val edgeeleven = new Edge(nodefive, nodefour, "edgeeleven")
    val edgetwelve = new Edge(nodefive, nodesix, "edgetwelve")
    val edgethirteen = new Edge(nodefive, nodeseven, "edgethirteen")

    val edgefourteen = new Edge(nodesix, nodefour, "edgefourteen")
    val edgefifteen = new Edge(nodesix, nodefive, "edgefifteen")
    val edgesixteen = new Edge(nodesix, nodeseven, "edgesixteen")

    val edgeseventeen = new Edge(nodeseven, nodesix, "edgeseventeen")
    val edgeeighteen = new Edge(nodeseven, nodefive, "edgeeighteen")

    val myGraph = new StreetGraph

    myGraph.intersections += nodeone.id -> nodeone
    myGraph.intersections += nodetwo.id -> nodetwo
    myGraph.intersections += nodethree.id -> nodethree
    myGraph.intersections += nodefour.id -> nodefour
    myGraph.intersections += nodefive.id -> nodefive
    myGraph.intersections += nodesix.id -> nodesix
    myGraph.intersections += nodeseven.id -> nodeseven

    myGraph.edges.append(edgeone)
    myGraph.edges.append(edgetwo)
    myGraph.edges.append(edgethree)
    myGraph.edges.append(edgefour)
    myGraph.edges.append(edgefive)
    myGraph.edges.append(edgesix)
    myGraph.edges.append(edgeseven)
    myGraph.edges.append(edgeeight)
    myGraph.edges.append(edgenine)
    myGraph.edges.append(edgeten)
    myGraph.edges.append(edgeeleven)
    myGraph.edges.append(edgetwelve)
    myGraph.edges.append(edgethirteen)
    myGraph.edges.append(edgefourteen)
    myGraph.edges.append(edgefifteen)
    myGraph.edges.append(edgesixteen)
    myGraph.edges.append(edgeseventeen)
    myGraph.edges.append(edgeeighteen)

    val adjlist = MapUtils.pathWithFewestIntersections(myGraph,MapUtils.computeOutgoingEdges(myGraph),nodeone.id,nodefive.id)

    assert(adjlist.size==3)
    assert(adjlist.head == edgetwo )
    assert(adjlist(1) == edgeseven )
    assert(adjlist(2) == edgenine )
    assert(adjlist.equals(List(edgetwo,edgeseven,edgenine)))
  }

  it must "shortest distance" in {
    val nodeone = new Intersection("newone", 3, 0)
    val nodetwo = new Intersection("newtwo", 0, 5)
    val nodethree = new Intersection("newthree", -4, 0)
    val nodefour = new Intersection("newfour", -1, -1)
    val nodefive = new Intersection("newfive", 1, -1)

    val edgeone = new Edge(nodeone, nodetwo, "edgeone")
    val edgetwo = new Edge(nodeone, nodefive, "edgetwo")

    val edgethree = new Edge(nodetwo, nodeone, "edgethree")
    val edgefour = new Edge(nodetwo, nodethree, "edgefour")

    val edgefive = new Edge(nodethree, nodetwo, "edgefive")
    val edgesix = new Edge(nodethree, nodefour, "edgesix")

    val edgeseven = new Edge(nodefour, nodethree, "edgeseven")
    val edgeeight = new Edge(nodefour, nodefive, "edgeeight")

    val edgenine = new Edge(nodefive, nodefour, "edgenine")
    val edgeten = new Edge(nodefive, nodeone, "edgeten")

    val myGraph = new StreetGraph

    myGraph.intersections += nodeone.id -> nodeone
    myGraph.intersections += nodetwo.id -> nodetwo
    myGraph.intersections += nodethree.id -> nodethree
    myGraph.intersections += nodefour.id -> nodefour
    myGraph.intersections += nodefive.id -> nodefive

    myGraph.edges.append(edgeone)
    myGraph.edges.append(edgetwo)
    myGraph.edges.append(edgethree)
    myGraph.edges.append(edgefour)
    myGraph.edges.append(edgefive)
    myGraph.edges.append(edgesix)
    myGraph.edges.append(edgeseven)
    myGraph.edges.append(edgeeight)
    myGraph.edges.append(edgenine)
    myGraph.edges.append(edgeten)

    val adjlist = MapUtils.pathWithShortestDistance(myGraph,MapUtils.computeOutgoingEdges(myGraph),nodeone.id,nodethree.id)

    assert(adjlist.size==3)
    assert(adjlist.head==edgetwo)
    assert(adjlist(1)==edgenine)
    assert(adjlist(2)==edgeseven)
    assert(adjlist.equals(List(edgetwo,edgenine,edgeseven)))
  }
  it must "extra credit" in{
  val nodeone = new Intersection("newone", 3, 0)
  val nodetwo = new Intersection("newtwo", 0, 1)
  val nodethree = new Intersection("newthree", -4, 0)
  val nodefour = new Intersection("newfour", -1, -1)
  val nodefive = new Intersection("newfive", 1, -1)

  val edgeone = new Edge(nodeone, nodetwo, "edgeone")
  val edgetwo = new Edge(nodeone, nodefive, "edgetwo")

  val edgethree = new Edge(nodetwo, nodeone, "edgethree")
  val edgefour = new Edge(nodetwo, nodethree, "edgefour")

  val edgefive = new Edge(nodethree, nodetwo, "edgefive")
  val edgesix = new Edge(nodethree, nodefour, "edgesix")

  val edgeseven = new Edge(nodefour, nodethree, "edgeseven")
  val edgeeight = new Edge(nodefour, nodefive, "edgeeight")

  val edgenine = new Edge(nodefive, nodefour, "edgenine")
  val edgeten = new Edge(nodefive, nodeone, "edgeten")

  val myGraph = new StreetGraph

  myGraph.intersections += nodeone.id -> nodeone
  myGraph.intersections += nodetwo.id -> nodetwo
  myGraph.intersections += nodethree.id -> nodethree
  myGraph.intersections += nodefour.id -> nodefour
  myGraph.intersections += nodefive.id -> nodefive

  myGraph.edges.append(edgeone)
  myGraph.edges.append(edgetwo)
  myGraph.edges.append(edgethree)
  myGraph.edges.append(edgefour)
  myGraph.edges.append(edgefive)
  myGraph.edges.append(edgesix)
  myGraph.edges.append(edgeseven)
  myGraph.edges.append(edgeeight)
  myGraph.edges.append(edgenine)
  myGraph.edges.append(edgeten)

  val adjlist = MapUtils.pathWithFewestIntersections(myGraph,MapUtils.computeOutgoingEdges(myGraph),nodeone.id,nodethree.id)

  assert(adjlist.size==2)
  assert(adjlist.head==edgeone)
  assert(adjlist(1)==edgefour)
  //assert(adjlist(2)==edgeseven)
  assert(adjlist.equals(List(edgeone,edgefour)))
}
  }